index.html - minimal lines of code, easy as pie to follow along with

canvas2webm.js - the js portion -- remove the demo stuff obviously for use in your own stuff -- upload file to server via ajax, process via php (upload.php)

upload.php - process the file uploaded via the ajax in the .js file

uploads folder - init.placeholder file in it to make sure uploads folder gets created